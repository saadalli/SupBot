'use client'
import { useEffect, useState } from 'react';
import axios from 'axios';
import MainLayout from '@/app/components/MainLayout';
import CreateReminderForm from '@/app/components/CreateReminderForm';

export default function Reminders() {
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    fetchReminders();
  }, []);

  const fetchReminders = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8080/api/v1/user/reminders', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setReminders(response.data.reminders);
    } catch (error) {
      console.error('Error fetching reminders:', error);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Reminders</h1>
        <CreateReminderForm onReminderCreated={fetchReminders} />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {reminders?.map((reminder) => (
            <div key={reminder.id} className="bg-white p-4 rounded-lg shadow-md">
              <p className="text-gray-700">Task ID: {reminder.task_id}</p>
              <p className="text-sm text-gray-500">
                Reminder: {new Date(reminder.reminder_date).toLocaleString()}
              </p>
              <p className={`text-sm ${reminder.status === 'sent' ? 'text-green-500' : 'text-yellow-500'}`}>
                Status: {reminder.status}
              </p>
            </div>
          ))}
        </div>
      </div>
    </MainLayout>
  );
}