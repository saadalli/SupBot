'use client';
import { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import MainLayout from '@/app/components/MainLayout';

export default function FAQs() {
  const [faqs, setFaqs] = useState([]); // Store FAQs from the API
  const [chatHistory, setChatHistory] = useState([]); // Store chat history (questions and answers)
  const chatBoxRef = useRef(null); // Ref for the chat box

  useEffect(() => {
    fetchFAQs();
    // Load chat history from local storage on component mount
    const storedChatHistory = localStorage.getItem('chatHistory');
    if (storedChatHistory) {
      setChatHistory(JSON.parse(storedChatHistory));
    }
  }, []);

  // Auto-scroll to the bottom of the chat box when chat history updates
  useEffect(() => {
    if (chatBoxRef.current) {
      chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight;
    }
  }, [chatHistory]);

  // Fetch FAQs from the API
  const fetchFAQs = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/v1/user/faqs');
      setFaqs(response.data.faqs);
    } catch (error) {
      console.error('Error fetching FAQs:', error);
    }
  };

  // Handle clicking on a question
  const handleQuestionClick = (faq) => {
    // Add the question and answer to the chat history
    const newChatHistory = [
      ...chatHistory,
      { type: 'sender', text: faq.question }, // Sender message (question)
      { type: 'receiver', text: faq.answer }, // Receiver message (answer)
    ];
    setChatHistory(newChatHistory);

    // Save the updated chat history to local storage
    localStorage.setItem('chatHistory', JSON.stringify(newChatHistory));
  };

  // Clear chat history
  const clearChat = () => {
    setChatHistory([]);
    localStorage.removeItem('chatHistory');
  };

  return (
    <MainLayout>
      <div className="flex flex-col h-[90vh] p-4">
        {/* Chat Box (Top) */}
        <div
          ref={chatBoxRef} // Attach the ref to the chat box
          className="flex-1 overflow-y-auto mb-4 border border-gray-300 rounded-lg p-4"
        >
          {chatHistory.map((chat, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg max-w-[40%] ${
                chat.type === 'sender'
                  ? 'bg-blue-500 text-white self-end ml-auto' // Sender message (question)
                  : 'bg-gray-200 text-gray-700 self-start' // Receiver message (answer)
              }`}
            >
              <p>{chat.text}</p>
            </div>
          ))}
        </div>

        {/* Questions List (Bottom) */}
        <div className="space-y-2">
          {faqs?.map((faq) => (
            <div
              key={faq.id}
              className="bg-white p-4 rounded-lg shadow-md cursor-pointer hover:bg-gray-100"
              onClick={() => handleQuestionClick(faq)} // Add question and answer to chat history
            >
              <h2 className="text-xl font-semibold">{faq.question}</h2>
            </div>
          ))}
        </div>

        {/* Clear Chat Button */}
        <button
          onClick={clearChat}
          className="mt-4 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
        >
          Clear Chat
        </button>
      </div>
    </MainLayout>
  );
}