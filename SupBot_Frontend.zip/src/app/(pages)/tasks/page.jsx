'use client'
import { useEffect, useState } from 'react';
import axios from 'axios';
import MainLayout from '@/app/components/MainLayout';
import CreateTaskForm from '@/app/components/CreateTaskForm';

export default function Tasks() {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8080/api/v1/user/tasks', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTasks(response.data.tasks);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  return (
    <MainLayout>
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Tasks</h1>
        <CreateTaskForm onTaskCreated={fetchTasks} />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tasks?.map((task) => (
            <div key={task.id} className="bg-white p-4 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold">{task.title}</h2>
              <p className="text-gray-700">{task.description}</p>
              <p className="text-sm text-gray-500">Due: {new Date(task.due_date).toLocaleString()}</p>
              <p className={`text-sm ${task.status === 'completed' ? 'text-green-500' : 'text-yellow-500'}`}>
                Status: {task.status}
              </p>
            </div>
          ))}
        </div>
      </div>
    </MainLayout>
  );
}