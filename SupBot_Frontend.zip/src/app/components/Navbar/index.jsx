'use client'
import Link from 'next/link';
import { useState } from 'react';
import LoginModal from '../LoginModal';
import SignupModal from '../SignupModal';
export default function Navbar() {
    const [isLoginOpen, setIsLoginOpen] = useState(false);
    const [isSignupOpen, setIsSignupOpen] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const handleLogin = () => {
        setIsLoggedIn(true);
    };

    return (
        <nav className="bg-blue-600 p-4 text-white">
            <div className="container mx-auto flex justify-between items-center">
                <Link href="/">
                    <span className="text-xl font-bold cursor-pointer">Task Manager</span>
                </Link>
                <div className="space-x-4">
             
                    <Link href="/chatbot">
                        <span className="cursor-pointer">Chat Bot</span>
                    </Link>
                    <Link href="/tasks">
                        <span className="cursor-pointer">Tasks</span>
                    </Link>
                    <Link href="/reminders">
                        <span className="cursor-pointer">Reminders</span>
                    </Link>
                    <Link href="/faqs">
                        <span className="cursor-pointer">FAQs</span>
                    </Link>
                    {!isLoggedIn ? (
                        <>
                            <button onClick={() => setIsLoginOpen(true)} className="cursor-pointer">
                                Login
                            </button>
                            <button onClick={() => setIsSignupOpen(true)} className="cursor-pointer">
                                Signup
                            </button>
                        </>
                    ) : (
                        <span>Welcome, User!</span>
                    )}
                </div>
            </div>
            <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} onLogin={handleLogin} />
            <SignupModal isOpen={isSignupOpen} onClose={() => setIsSignupOpen(false)} />
        </nav>
    );
}